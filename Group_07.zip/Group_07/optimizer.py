# ==============================================================================
# Group_07 — Quantitative Optimization Solvers
# Markowitz Mean-Variance, Ledoit-Wolf Shrinkage, Risk Parity
# ==============================================================================

import numpy as np
import scipy.optimize as sco

def calculate_covariance_matrix(df_returns, tickers, shrinkage_intensity=0.20):
    """
    Computes annualized covariance and correlation matrices with Ledoit-Wolf constant correlation shrinkage.
    """
    returns_matrix = df_returns[tickers].values
    n = len(tickers)
    
    # Sample mean and standard deviation
    means = np.nanmean(returns_matrix, axis=0)
    stds = np.nanstd(returns_matrix, axis=0, ddof=1)
    
    sample_cov = np.cov(returns_matrix, rowvar=False)
    
    # Constant correlation target
    corr_matrix = np.corrcoef(returns_matrix, rowvar=False)
    avg_corr = (np.sum(corr_matrix) - n) / (n * (n - 1)) if n > 1 else 0.20
    
    target_cov = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            if i == j:
                target_cov[i, j] = sample_cov[i, j]
            else:
                target_cov[i, j] = avg_corr * stds[i] * stds[j]
                
    # Shrunk covariance matrix (annualized by 252)
    lambda_param = np.clip(shrinkage_intensity, 0.0, 1.0)
    shrunk_cov = (1 - lambda_param) * sample_cov + lambda_param * target_cov
    shrunk_cov_ann = shrunk_cov * 252
    
    ann_returns = {tickers[i]: float(means[i] * 252) for i in range(n)}
    
    return shrunk_cov_ann, corr_matrix, ann_returns

def optimize_max_sharpe(tickers, df_returns, cov_matrix, ann_returns, risk_free_rate=0.045, max_weight=0.35):
    """
    Solves for Tangency Portfolio (Max Sharpe Ratio) under bounded long-only constraints.
    """
    n = len(tickers)
    r_vec = np.array([ann_returns[t] for t in tickers])
    
    def neg_sharpe(weights):
        p_ret = np.dot(weights, r_vec)
        p_vol = np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights)))
        return -(p_ret - risk_free_rate) / max(1e-8, p_vol)
    
    constraints = ({'type': 'eq', 'fun': lambda w: np.sum(w) - 1.0})
    bounds = tuple((0.0, max_weight) for _ in range(n))
    init_guess = np.array([1.0 / n] * n)
    
    opt_res = sco.minimize(neg_sharpe, init_guess, method='SLSQP', bounds=bounds, constraints=constraints)
    
    weights = opt_res.x if opt_res.success else init_guess
    weights = weights / np.sum(weights)
    
    exp_ret = float(np.dot(weights, r_vec))
    vol = float(np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights))))
    sharpe = (exp_ret - risk_free_rate) / max(1e-8, vol)
    
    return {
        'weights': {tickers[i]: float(weights[i]) for i in range(n)},
        'expected_return': exp_ret,
        'volatility': vol,
        'sharpe_ratio': float(sharpe)
    }

def optimize_min_variance(tickers, df_returns, cov_matrix, ann_returns, max_weight=0.35):
    """
    Solves for the Global Minimum Variance Portfolio.
    """
    n = len(tickers)
    r_vec = np.array([ann_returns[t] for t in tickers])
    
    def portfolio_vol(weights):
        return np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights)))
        
    constraints = ({'type': 'eq', 'fun': lambda w: np.sum(w) - 1.0})
    bounds = tuple((0.0, max_weight) for _ in range(n))
    init_guess = np.array([1.0 / n] * n)
    
    opt_res = sco.minimize(portfolio_vol, init_guess, method='SLSQP', bounds=bounds, constraints=constraints)
    weights = opt_res.x if opt_res.success else init_guess
    weights = weights / np.sum(weights)
    
    exp_ret = float(np.dot(weights, r_vec))
    vol = float(np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights))))
    
    return {
        'weights': {tickers[i]: float(weights[i]) for i in range(n)},
        'expected_return': exp_ret,
        'volatility': vol,
        'sharpe_ratio': float((exp_ret - 0.045) / max(1e-8, vol))
    }

def optimize_risk_parity(tickers, cov_matrix, ann_returns, risk_free_rate=0.045):
    """
    Equal Risk Contribution (ERC) inverse volatility formulation.
    """
    n = len(tickers)
    vols = np.sqrt(np.diag(cov_matrix))
    inv_vols = 1.0 / np.maximum(1e-4, vols)
    weights = inv_vols / np.sum(inv_vols)
    
    r_vec = np.array([ann_returns[t] for t in tickers])
    exp_ret = float(np.dot(weights, r_vec))
    vol = float(np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights))))
    
    return {
        'weights': {tickers[i]: float(weights[i]) for i in range(n)},
        'expected_return': exp_ret,
        'volatility': vol,
        'sharpe_ratio': float((exp_ret - risk_free_rate) / max(1e-8, vol))
    }

def generate_efficient_frontier(tickers, cov_matrix, ann_returns, min_vol_res, max_sharpe_res, risk_free_rate=0.045, steps=30):
    """
    Traces the Markowitz Efficient Frontier between Min Vol and Max Sharpe.
    """
    frontier_points = []
    w_min = np.array([min_vol_res['weights'][t] for t in tickers])
    w_max = np.array([max_sharpe_res['weights'][t] for t in tickers])
    r_vec = np.array([ann_returns[t] for t in tickers])
    
    for alpha in np.linspace(0, 1.5, steps):
        w = (1 - alpha) * w_min + alpha * w_max
        w = np.maximum(0, w)
        if np.sum(w) > 0:
            w = w / np.sum(w)
            ret = float(np.dot(w, r_vec))
            vol = float(np.sqrt(np.dot(w.T, np.dot(cov_matrix, w))))
            sharpe = (ret - risk_free_rate) / max(1e-8, vol)
            frontier_points.append({'volatility': vol, 'return': ret, 'sharpe': sharpe})
            
    return frontier_points
