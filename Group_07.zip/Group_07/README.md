# Group_07 — Crisis Tail-Risk & Volatility Shield Optimizer

### Overview
This package contains the complete quantitative optimization engine, empirical data cleaning pipeline, Streamlit interactive application, and independent mathematical verification suite developed for **Group_07**.

### Live Streamlit Application
- **Deployed App URL:** [https://crisis-shield-portfolio.streamlit.app](https://crisis-shield-portfolio.streamlit.app)

### Quickstart (Running Locally)
```bash
# 1. Create a virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Launch Streamlit interactive workbench
streamlit run app.py

# 4. Run automated pytest test suite
pytest test_optimizer.py
```
