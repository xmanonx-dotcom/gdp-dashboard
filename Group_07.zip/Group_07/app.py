# ==============================================================================
# Group_07 — Crisis Tail-Risk & Volatility Shield Optimizer
# Streamlit Interactive Financial Application
# Deployed URL: https://crisis-shield-portfolio.streamlit.app
# ==============================================================================

import streamlit as st
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from data_loader import fetch_financial_data, get_asset_metadata
from optimizer import (
    calculate_covariance_matrix,
    optimize_max_sharpe,
    optimize_min_variance,
    optimize_risk_parity,
    generate_efficient_frontier
)
from verification import run_independent_verification_suite

st.set_page_config(
    page_title="Crisis Shield | Portfolio Optimizer (Group_07)",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.title("🛡️ Crisis Tail-Risk & Volatility Shield Optimizer")
st.caption(f"Quantitative Portfolio Optimization & Tail-Risk Engineering | Group: {groupNumber}")

# Sidebar Controls
st.sidebar.header("⚙️ Market Assumptions & Constraints")
tickers = st.sidebar.multiselect(
    "Asset Universe",
    options=["SPY", "TLT", "GLD", "DBMF", "QQQ", "IEF", "VNQ", "DBC", "TIP"],
    default=["SPY", "TLT", "GLD", "DBMF"]
)

lookback_years = st.sidebar.slider("Lookback Horizon (Years)", 1, 5, 4)
risk_free_rate = st.sidebar.number_input("Risk-Free Rate (Rf)", 0.0, 0.10, 0.045, 0.005)
max_weight = st.sidebar.slider("Max Single-Asset Cap", 0.20, 1.00, 0.35, 0.05)
shrinkage = st.sidebar.slider("Ledoit-Wolf Shrinkage Intensity (λ)", 0.0, 1.0, 0.20, 0.05)

# Load data
with st.spinner("Fetching verified yFinance empirical price feeds..."):
    df_prices, df_returns, provenance = fetch_financial_data(tickers, lookback_years)

st.success(f"✓ Successfully aligned {len(df_prices)} trading days from {provenance['date_range']}")

# Covariance & Optimizations
cov_matrix, corr_matrix, ann_returns = calculate_covariance_matrix(df_returns, tickers, shrinkage_intensity=shrinkage)

col1, col2 = st.columns([7, 5])

with col1:
    st.subheader("📈 Markowitz Efficient Frontier")
    max_sharpe_res = optimize_max_sharpe(tickers, df_returns, cov_matrix, ann_returns, risk_free_rate, max_weight)
    min_vol_res = optimize_min_variance(tickers, df_returns, cov_matrix, ann_returns, max_weight)
    risk_parity_res = optimize_risk_parity(tickers, cov_matrix, ann_returns, risk_free_rate)
    
    frontier = generate_efficient_frontier(tickers, cov_matrix, ann_returns, min_vol_res, max_sharpe_res, risk_free_rate)
    
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=[p['volatility'] * 100 for p in frontier],
        y=[p['return'] * 100 for p in frontier],
        mode='lines',
        name='Efficient Frontier',
        line=dict(color='#2563EB', width=3)
    ))
    
    # Add portfolios
    fig.add_trace(go.Scatter(
        x=[max_sharpe_res['volatility'] * 100],
        y=[max_sharpe_res['expected_return'] * 100],
        mode='markers+text',
        name='★ Max Sharpe',
        text=['Max Sharpe (Tangency)'],
        textposition='top left',
        marker=dict(size=14, color='#2563EB')
    ))
    fig.update_layout(
        xaxis_title="Annualized Volatility (%)",
        yaxis_title="Expected Annual Return (%)",
        template="plotly_white",
        height=420
    )
    st.plotly_chart(fig, use_container_width=True)

with col2:
    st.subheader("⚖️ Recommended Allocations ($1.25M)")
    weights_df = pd.DataFrame({
        'Max Sharpe': [f"{max_sharpe_res['weights'].get(t,0)*100:.1f}%" for t in tickers],
        'Min Volatility': [f"{min_vol_res['weights'].get(t,0)*100:.1f}%" for t in tickers],
        'Risk Parity': [f"{risk_parity_res['weights'].get(t,0)*100:.1f}%" for t in tickers]
    }, index=tickers)
    st.dataframe(weights_df, use_container_width=True)
    
    st.metric("Expected Portfolio Return", f"{max_sharpe_res['expected_return']*100:.2f}%")
    st.metric("Portfolio Volatility", f"{max_sharpe_res['volatility']*100:.2f}%")
    st.metric("Sharpe Ratio (Rf=4.5%)", f"{max_sharpe_res['sharpe_ratio']:.2f}")

# Verification Audit
st.divider()
st.subheader("🛡️ Independent Verification & Arithmetic Audit")
audit_checks = run_independent_verification_suite(max_sharpe_res, cov_matrix, ann_returns, tickers, df_returns)
st.table(pd.DataFrame(audit_checks))
