# ==============================================================================
# Group_07 — Pytest Unit Test Suite
# ==============================================================================

import pytest
import numpy as np
import pandas as pd
from optimizer import (
    calculate_covariance_matrix,
    optimize_max_sharpe,
    optimize_min_variance
)

def test_sum_to_one_constraint():
    tickers = ['SPY', 'TLT', 'GLD', 'DBMF']
    df_returns = pd.DataFrame(np.random.normal(0.0004, 0.01, (500, 4)), columns=tickers)
    cov, corr, ann_ret = calculate_covariance_matrix(df_returns, tickers)
    
    res = optimize_max_sharpe(tickers, df_returns, cov, ann_ret, risk_free_rate=0.045, max_weight=0.35)
    sum_w = sum(res['weights'].values())
    assert abs(sum_w - 1.0) < 1e-4, f"Weights must sum to 1.0, got {sum_w}"

def test_max_weight_bounds():
    tickers = ['SPY', 'TLT', 'GLD', 'DBMF']
    df_returns = pd.DataFrame(np.random.normal(0.0004, 0.01, (500, 4)), columns=tickers)
    cov, corr, ann_ret = calculate_covariance_matrix(df_returns, tickers)
    
    max_cap = 0.35
    res = optimize_max_sharpe(tickers, df_returns, cov, ann_ret, risk_free_rate=0.045, max_weight=max_cap)
    for t, w in res['weights'].items():
        assert w <= max_cap + 1e-4, f"Weight for {t} exceeded {max_cap}: {w}"
