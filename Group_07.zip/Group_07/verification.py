# ==============================================================================
# Group_07 — Independent Verification Suite
# Decoupled Mathematical Precision & Robustness Audits
# ==============================================================================

import numpy as np

def run_independent_verification_suite(port_result, cov_matrix, ann_returns, tickers, df_returns):
    """
    Executes 4 independent mathematical sanity checks verifying that portfolio 
    calculations are free of precision defects, singularity errors, or budget leaks.
    """
    weights = np.array([port_result['weights'][t] for t in tickers])
    checks = []
    
    # 1. Budget Constraint: Sum-to-one
    sum_w = float(np.sum(weights))
    checks.append({
        'Audit Name': 'Budget Constraint (Sum-to-One)',
        'Status': 'Passed' if abs(sum_w - 1.0) < 1e-4 else 'Warning',
        'Matrix Result': f"{sum_w * 100:.4f}%",
        'Independent Expected': "100.0000%",
        'Delta Discrepancy': f"{abs(sum_w - 1.0) * 100:.4f}%",
        'Mathematical Proof': "∑ w_i == 1.0000"
    })
    
    # 2. Dual Volatility Formula: Matrix w^T Σ w vs Empirical Series Std Dev
    matrix_vol = float(np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights))))
    
    # Independent Series Recomputation
    daily_returns = df_returns[tickers].dot(weights)
    empirical_vol = float(np.std(daily_returns, ddof=1) * np.sqrt(252))
    vol_delta = abs(matrix_vol - empirical_vol)
    
    checks.append({
        'Audit Name': 'Dual Volatility Formulation',
        'Status': 'Passed' if vol_delta < 0.015 else 'Warning',
        'Matrix Result': f"{matrix_vol * 100:.3f}%",
        'Independent Expected': f"{empirical_vol * 100:.3f}%",
        'Delta Discrepancy': f"{vol_delta * 100:.4f}%",
        'Mathematical Proof': "σ_p = √(w^T Σ w) ≡ StdDev(R_p) * √252"
    })
    
    # 3. Covariance Condition Number (Non-singularity)
    eigenvalues = np.linalg.eigvals(cov_matrix)
    condition_number = float(np.max(eigenvalues) / max(1e-8, np.min(eigenvalues)))
    
    checks.append({
        'Audit Name': 'Covariance Matrix Non-Singularity',
        'Status': 'Passed' if condition_number < 300 else 'Warning',
        'Matrix Result': f"κ(Σ) = {condition_number:.1f}",
        'Independent Expected': "κ < 300 (Stable)",
        'Delta Discrepancy': "0.000 (Non-Singular)",
        'Mathematical Proof': "λ_min > 0 (Positive Definite)"
    })
    
    # 4. Sharpe Ratio Slope Formula
    rf = 0.045
    calc_sharpe = (port_result['expected_return'] - rf) / max(1e-8, matrix_vol)
    sharpe_delta = abs(port_result['sharpe_ratio'] - calc_sharpe)
    
    checks.append({
        'Audit Name': 'Sharpe Ratio & CAL Slope',
        'Status': 'Passed' if sharpe_delta < 0.05 else 'Warning',
        'Matrix Result': f"SR = {port_result['sharpe_ratio']:.3f}",
        'Independent Expected': f"SR = {calc_sharpe:.3f}",
        'Delta Discrepancy': f"{sharpe_delta:.4f}",
        'Mathematical Proof': "Sharpe = (E[R_p] - Rf) / σ_p"
    })
    
    return checks
